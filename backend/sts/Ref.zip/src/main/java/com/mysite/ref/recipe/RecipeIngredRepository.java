package com.mysite.ref.recipe;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RecipeIngredRepository extends JpaRepository<RecipeIngred, Integer> {
}
