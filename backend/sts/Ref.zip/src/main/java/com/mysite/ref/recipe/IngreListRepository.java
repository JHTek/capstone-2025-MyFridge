package com.mysite.ref.recipe;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IngreListRepository extends JpaRepository<IngreList, Integer> {

}
