package com.mysite.ref.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoteUpdateRequestDTO {
	private String note;
}
