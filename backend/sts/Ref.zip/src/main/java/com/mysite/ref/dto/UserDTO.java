package com.mysite.ref.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {
	
	private String userid;
	private String username;
	private String password;

}
