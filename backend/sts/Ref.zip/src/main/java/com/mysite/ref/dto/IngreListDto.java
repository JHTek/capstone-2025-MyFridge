package com.mysite.ref.dto;

public class IngreListDto {
    private String ingre_name;
    private String ingre_count;
    private String ingre_unit;

    // getters and setters
    public String getIngre_name() { return ingre_name; }
    public void setIngre_name(String ingre_name) { this.ingre_name = ingre_name; }
    public String getIngre_count() { return ingre_count; }
    public void setIngre_count(String ingre_count) { this.ingre_count = ingre_count; }
    public String getIngre_unit() { return ingre_unit; }
    public void setIngre_unit(String ingre_unit) { this.ingre_unit = ingre_unit; }
}